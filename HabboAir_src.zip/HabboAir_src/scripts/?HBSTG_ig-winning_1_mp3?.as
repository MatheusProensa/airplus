package
{
   import flash.media.Sound;
   
   [Embed(source="/_assets/1462_HBSTG_ig-winning_1_mp3.mp3")]
   public class §HBSTG_ig-winning_1_mp3§ extends Sound
   {
      public function §HBSTG_ig-winning_1_mp3§()
      {
         super();
      }
   }
}

