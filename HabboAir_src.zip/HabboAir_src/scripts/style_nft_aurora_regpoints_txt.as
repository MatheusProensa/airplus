package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/747_style_nft_aurora_regpoints_txt.bin", mimeType="application/octet-stream")]
   public class style_nft_aurora_regpoints_txt extends ByteArray
   {
      public function style_nft_aurora_regpoints_txt()
      {
         super();
      }
   }
}

