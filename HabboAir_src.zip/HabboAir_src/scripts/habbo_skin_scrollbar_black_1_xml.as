package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/2732_habbo_skin_scrollbar_black_1_xml.bin", mimeType="application/octet-stream")]
   public class habbo_skin_scrollbar_black_1_xml extends ByteArray
   {
      public function habbo_skin_scrollbar_black_1_xml()
      {
         super();
      }
   }
}

