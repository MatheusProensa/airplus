package
{
   import flash.utils.ByteArray;
   
   public class §_a_-_-_§
   {
      var _loc1_:Boolean = false;
      var _loc2_:Boolean = true;
      
      private var §_a_-___§:int = 0;
      
      private var §_a_---__§:int = 0;
      
      private var §_a_-_-_-§:ByteArray;
      
      private const §_a_-__--§:uint = 256;
      
      public function §_a_-_-_§(param1:ByteArray = null)
      {
         var _loc2_:Boolean = false;
         var _loc3_:Boolean = true;
         if(!_loc2_)
         {
            super();
            if(!_loc2_)
            {
               this.§_a_-_-_-§ = new ByteArray();
               if(_loc2_)
               {
               }
               §§goto(addr25);
            }
         }
         if(param1)
         {
            if(_loc3_)
            {
               §§goto(addr25);
            }
         }
         addr25:
         this.§_a_-§(param1);
      }
      
      public function §_a_--___§() : uint
      {
         var _loc1_:Boolean = true;
         var _loc2_:Boolean = false;
         return this.§_a_-__--§;
      }
      
      public function §_a_-§(param1:ByteArray) : void
      {
         var _loc5_:* = false;
         var _loc6_:* = true;
         §§push(0);
         if(!_loc6_)
         {
            §§push(((§§pop() + 1) * 9 + 1 + 1) * 116);
         }
         var _loc2_:* = §§pop();
         §§push(0);
         if(!_loc6_)
         {
            §§push(-§§pop() - 1 + 1 - 51);
         }
         var _loc3_:* = §§pop();
         §§push(0);
         if(_loc5_)
         {
            §§push((§§pop() * 50 - 1 + 1) * 9 - 1);
         }
         var _loc4_:* = §§pop();
         if(!_loc5_)
         {
            §§push(0);
            if(!_loc6_)
            {
               §§push(-(§§pop() + 1) + 82 + 4 + 1 - 1);
            }
            if(_loc6_)
            {
               _loc2_ = §§pop();
               if(!_loc5_)
               {
                  while(true)
                  {
                     §§push(_loc2_);
                     if(_loc5_)
                     {
                     }
                     break;
                  }
                  §§goto(addr155);
               }
               addr141:
               §§push(0);
               if(!_loc6_)
               {
                  §§push(--(§§pop() - 1) + 1 + 75 - 1 - 1);
               }
               if(_loc6_)
               {
                  §§goto(addr155);
               }
               §§goto(addr289);
            }
            while(true)
            {
               §§push(256);
               if(!_loc6_)
               {
                  §§push((§§pop() - 27) * 52 - 1);
               }
               if(!_loc5_)
               {
                  if(§§pop() >= §§pop())
                  {
                     if(_loc6_)
                     {
                     }
                     §§goto(addr141);
                  }
                  else
                  {
                     if(_loc5_)
                     {
                        _loc2_ = _loc2_;
                        _loc2_ = _loc2_;
                        _loc5_ = _loc5_;
                        loop8:
                        while(true)
                        {
                           _loc2_++;
                           if(!_loc5_)
                           {
                              if(!_loc6_)
                              {
                                 _loc5_ = _loc5_;
                                 _loc2_ = _loc2_;
                                 _loc3_ = _loc3_;
                              }
                              §§goto(addr102);
                           }
                           addr91:
                           while(true)
                           {
                              if(!_loc6_)
                              {
                                 break loop8;
                              }
                              continue loop8;
                           }
                           §§goto(addr102);
                           addr102:
                        }
                        _loc3_ = _loc3_;
                        _loc3_ = _loc3_;
                        param1 = param1;
                        §§goto(addr102);
                     }
                     while(true)
                     {
                        this.§_a_-_-_-§[_loc2_] = _loc2_;
                        §§goto(addr91);
                     }
                  }
                  addr155:
                  _loc2_ = §§pop();
                  if(_loc6_)
                  {
                     loop1:
                     while(true)
                     {
                        §§push(_loc2_);
                        addr289:
                        while(true)
                        {
                           §§push(256);
                           if(!_loc6_)
                           {
                              §§push(§§pop() - 32 - 74 + 23 + 1 + 1);
                           }
                           addr300:
                           while(true)
                           {
                              if(§§pop() >= §§pop())
                              {
                                 break loop1;
                              }
                              if(!_loc6_)
                              {
                                 _loc4_ = _loc4_;
                                 _loc5_ = _loc5_;
                                 _loc6_ = _loc6_;
                                 loop2:
                                 while(true)
                                 {
                                    this.§_a_-_-_-§[_loc2_] = this.§_a_-_-_-§[_loc3_];
                                    if(_loc5_)
                                    {
                                       addr277:
                                       if(_loc6_)
                                       {
                                          break;
                                       }
                                       _loc5_ = _loc5_;
                                       param1 = param1;
                                       _loc3_ = _loc3_;
                                       loop3:
                                       while(true)
                                       {
                                          §§push(int(this.§_a_-_-_-§[_loc2_]));
                                          if(!_loc5_)
                                          {
                                             _loc4_ = §§pop();
                                             if(_loc6_)
                                             {
                                                if(_loc6_)
                                                {
                                                   break;
                                                }
                                                _loc2_ = _loc2_;
                                                _loc2_ = _loc2_;
                                                _loc4_ = _loc4_;
                                             }
                                             §§goto(addr277);
                                          }
                                          addr261:
                                          while(true)
                                          {
                                             _loc3_ = §§pop();
                                             if(!_loc5_)
                                             {
                                                if(!_loc6_)
                                                {
                                                   _loc3_ = _loc3_;
                                                   _loc6_ = _loc6_;
                                                   _loc4_ = _loc4_;
                                                   break loop2;
                                                }
                                                continue loop3;
                                             }
                                             §§goto(addr277);
                                          }
                                       }
                                       continue;
                                    }
                                    if(!_loc6_)
                                    {
                                       _loc3_ = _loc3_;
                                       _loc6_ = _loc6_;
                                       _loc2_ = _loc2_;
                                    }
                                    this.§_a_-_-_-§[_loc3_] = _loc4_;
                                    if(_loc6_)
                                    {
                                    }
                                    addr277:
                                    if(_loc5_)
                                    {
                                       this = this;
                                       _loc4_ = _loc4_;
                                       param1 = param1;
                                    }
                                    continue loop1;
                                 }
                                 _loc2_++;
                                 §§goto(addr277);
                              }
                              while(true)
                              {
                                 §§push(_loc3_);
                                 if(!_loc5_)
                                 {
                                    §§push(§§pop() + this.§_a_-_-_-§[_loc2_] + param1[_loc2_ % param1.length]);
                                    §§push(255);
                                    if(!_loc6_)
                                    {
                                       §§push((§§pop() * 36 + 82) * 114);
                                    }
                                    §§push(§§pop() & §§pop());
                                 }
                                 §§goto(addr261);
                              }
                           }
                        }
                     }
                     if(_loc5_)
                     {
                     }
                     §§goto(addr324);
                  }
                  if(_loc6_)
                  {
                  }
                  §§push(this);
                  §§push(0);
                  if(_loc5_)
                  {
                     §§push((-§§pop() * 22 + 38 + 1 + 1) * 8 + 1);
                  }
                  §§pop().§_a_-___§ = §§pop();
                  if(_loc6_)
                  {
                  }
                  §§goto(addr324);
               }
               break;
            }
            §§goto(addr300);
         }
         if(_loc5_)
         {
         }
         §§push(0);
         if(_loc5_)
         {
            §§push(§§pop() * 88 + 67 + 1 - 1 + 115 + 69);
         }
         if(_loc6_)
         {
            _loc3_ = §§pop();
            if(_loc6_)
            {
               §§goto(addr141);
            }
            addr324:
            §§push(this);
            §§push(0);
            if(_loc5_)
            {
               §§push(§§pop() + 1 + 1 + 68);
            }
            §§pop().§_a_---__§ = §§pop();
            return;
         }
         §§goto(addr155);
      }
      
      private function §_a_-__-§() : uint
      {
         var _loc2_:* = true;
         var _loc3_:* = false;
         §§push(0);
         if(!_loc2_)
         {
            §§push(-(§§pop() * 35 - 55 + 1 + 1));
         }
         var _loc1_:* = §§pop();
         if(!_loc3_)
         {
            §§push(this);
            §§push(this.§_a_-___§);
            if(_loc2_)
            {
               §§push(1);
               if(_loc3_)
               {
                  §§push(§§pop() + 1 + 0 + 91 - 1 + 1 + 1 - 1);
               }
               §§push(§§pop() + §§pop());
               §§push(255);
               if(!_loc2_)
               {
                  §§push(-(§§pop() + 1) - 1 + 1);
               }
               §§push(§§pop() & §§pop());
            }
            §§pop().§_a_-___§ = §§pop();
            if(_loc2_)
            {
               if(!_loc2_)
               {
                  this = this;
                  _loc2_ = _loc2_;
                  this = this;
               }
               §§push(this);
               §§push(this.§_a_---__§);
               if(!_loc3_)
               {
                  §§push(§§pop() + this.§_a_-_-_-§[this.§_a_-___§]);
                  §§push(255);
                  if(!_loc2_)
                  {
                     §§push(-(§§pop() - 107 - 1) * 47);
                  }
                  §§push(§§pop() & §§pop());
               }
               §§pop().§_a_---__§ = §§pop();
               if(_loc2_)
               {
                  if(!_loc2_)
                  {
                     _loc2_ = _loc2_;
                     _loc1_ = _loc1_;
                     this = this;
                     while(true)
                     {
                        this.§_a_-_-_-§[this.§_a_-___§] = this.§_a_-_-_-§[this.§_a_---__§];
                        if(_loc3_)
                        {
                        }
                        break;
                     }
                     addr150:
                     if(_loc3_)
                     {
                        _loc2_ = _loc2_;
                        _loc2_ = _loc2_;
                        _loc1_ = _loc1_;
                     }
                     §§push(this.§_a_-_-_-§);
                     §§push(_loc1_ + this.§_a_-_-_-§[this.§_a_-___§]);
                     §§push(255);
                     if(!_loc2_)
                     {
                        §§push(§§pop() - 60 - 119 - 1 - 1);
                     }
                     return §§pop()[§§pop() & §§pop()];
                     addr98:
                  }
                  while(true)
                  {
                     _loc1_ = int(this.§_a_-_-_-§[this.§_a_-___§]);
                     if(_loc2_)
                     {
                        if(!_loc2_)
                        {
                           _loc2_ = _loc2_;
                           this = this;
                           _loc1_ = _loc1_;
                        }
                        else
                        {
                           §§goto(addr98);
                        }
                        addr144:
                        this.§_a_-_-_-§[this.§_a_---__§] = _loc1_;
                     }
                     §§goto(addr150);
                  }
                  addr123:
               }
            }
         }
         while(!_loc2_)
         {
            _loc1_ = _loc1_;
            _loc3_ = _loc3_;
            _loc2_ = _loc2_;
            §§goto(addr123);
         }
         §§goto(addr144);
      }
      
      public function §_a_--_-_§() : uint
      {
         var _loc1_:Boolean = true;
         var _loc2_:Boolean = false;
         §§push(1);
         if(!_loc1_)
         {
            return (§§pop() + 1) * 7 - 1 + 1;
         }
      }
      
      public function §_a_-_--_§(param1:ByteArray) : void
      {
         var _loc4_:Boolean = false;
         var _loc5_:Boolean = true;
         §§push(0);
         if(!_loc5_)
         {
            §§push((--§§pop() + 1) * 86 - 1);
         }
         var _loc2_:uint = §§pop();
         if(_loc5_)
         {
            while(_loc2_ < param1.length)
            {
               var _loc3_:* = _loc2_++;
               param1[_loc3_] ^= this.§_a_-__-§();
            }
         }
      }
      
      public function §_a_---_§(param1:ByteArray) : void
      {
         var _loc2_:Boolean = false;
         var _loc3_:Boolean = true;
         if(!_loc2_)
         {
            this.§_a_-_--_§(param1);
         }
      }
      
      public function §_a_-_-§() : void
      {
         var _loc2_:* = false;
         var _loc3_:* = true;
         §§push(0);
         if(_loc2_)
         {
            §§push(-(§§pop() * 35 - 1) + 1);
         }
         var _loc1_:* = §§pop();
         if(_loc3_)
         {
            if(this.§_a_-_-_-§ != null)
            {
               if(!_loc2_)
               {
                  §§push(0);
                  if(!_loc3_)
                  {
                     §§push((§§pop() - 1 - 91) * 104 * 76 - 6 - 34 - 85);
                  }
                  §§push(§§pop());
                  if(!_loc2_)
                  {
                     _loc1_ = §§pop();
                     if(_loc3_)
                     {
                        while(true)
                        {
                           §§push(_loc1_);
                        }
                     }
                     addr120:
                     if(_loc2_)
                     {
                     }
                     §§push(this.§_a_-_-_-§);
                     §§push(0);
                     if(!_loc3_)
                     {
                        §§push(-(§§pop() + 1 + 49 - 1) * 86);
                     }
                     §§pop().length = §§pop();
                     if(!_loc2_)
                     {
                        if(_loc2_)
                        {
                           this = this;
                           _loc2_ = _loc2_;
                           _loc2_ = _loc2_;
                           while(true)
                           {
                              §§push(this);
                              §§push(0);
                              if(_loc2_)
                              {
                                 §§push(§§pop() * 55 + 1 - 1 - 1);
                              }
                              §§pop().§_a_---__§ = §§pop();
                              if(_loc3_)
                              {
                                 if(!_loc3_)
                                 {
                                    _loc2_ = _loc2_;
                                    _loc1_ = _loc1_;
                                    _loc3_ = _loc3_;
                                 }
                                 break;
                              }
                           }
                           addr218:
                           return;
                           addr148:
                        }
                        while(true)
                        {
                           this.§_a_-_-_-§ = null;
                           if(_loc2_)
                           {
                           }
                        }
                     }
                     while(true)
                     {
                        if(!_loc3_)
                        {
                           _loc2_ = _loc2_;
                           _loc1_ = _loc1_;
                           this = this;
                        }
                        else
                        {
                           §§goto(addr148);
                        }
                        §§goto(addr218);
                     }
                     addr207:
                  }
                  loop4:
                  while(§§pop() < this.§_a_-_-_-§.length)
                  {
                     if(_loc2_)
                     {
                        this = this;
                        _loc1_ = _loc1_;
                        _loc1_ = _loc1_;
                        loop5:
                        while(true)
                        {
                           §§push(_loc1_);
                           if(!_loc2_)
                           {
                              §§push(uint(§§pop() + 1));
                           }
                           _loc1_ = §§pop();
                           if(_loc3_)
                           {
                              if(!_loc2_)
                              {
                                 continue loop4;
                              }
                              this = this;
                              _loc2_ = _loc2_;
                              _loc1_ = _loc1_;
                           }
                           addr101:
                           while(true)
                           {
                              if(!_loc3_)
                              {
                                 break loop5;
                              }
                              continue loop5;
                           }
                           continue loop4;
                        }
                        _loc2_ = _loc2_;
                        _loc2_ = _loc2_;
                        this = this;
                        continue;
                     }
                     while(true)
                     {
                        §§push(this.§_a_-_-_-§);
                        §§push(_loc1_);
                        §§push(Math.random());
                        §§push(256);
                        if(!_loc3_)
                        {
                           §§push(-((§§pop() - 100) * 95) * 70 - 49);
                        }
                        §§pop()[§§pop()] = §§pop() * §§pop();
                        §§goto(addr101);
                     }
                  }
                  if(!_loc2_)
                  {
                     §§goto(addr120);
                  }
               }
            }
            while(true)
            {
               §§push(this);
               §§push(0);
               if(_loc2_)
               {
                  §§push(§§pop() + 86 - 1 - 90 - 112 + 1 - 36 + 55);
               }
               §§pop().§_a_-___§ = §§pop();
               §§goto(addr207);
            }
            addr190:
         }
         while(true)
         {
            if(_loc2_)
            {
               _loc1_ = _loc1_;
               _loc3_ = _loc3_;
               _loc1_ = _loc1_;
            }
            §§goto(addr190);
         }
      }
   }
}

