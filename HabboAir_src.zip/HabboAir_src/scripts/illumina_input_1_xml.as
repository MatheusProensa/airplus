package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/2130_illumina_input_1_xml.bin", mimeType="application/octet-stream")]
   public class illumina_input_1_xml extends ByteArray
   {
      public function illumina_input_1_xml()
      {
         super();
      }
   }
}

