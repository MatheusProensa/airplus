package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/1975_habbo_skin_frame_leaderboard_ach_1_xml.bin", mimeType="application/octet-stream")]
   public class habbo_skin_frame_leaderboard_ach_1_xml extends ByteArray
   {
      public function habbo_skin_frame_leaderboard_ach_1_xml()
      {
         super();
      }
   }
}

