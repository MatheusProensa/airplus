package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/2688_illumina_light_skin_switch_1_xml.bin", mimeType="application/octet-stream")]
   public class illumina_light_skin_switch_1_xml extends ByteArray
   {
      public function illumina_light_skin_switch_1_xml()
      {
         super();
      }
   }
}

