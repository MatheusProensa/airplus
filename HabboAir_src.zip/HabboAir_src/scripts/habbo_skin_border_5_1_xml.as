package
{
   import flash.utils.ByteArray;
   
   [Embed(source="/_assets/2684_habbo_skin_border_5_1_xml.bin", mimeType="application/octet-stream")]
   public class habbo_skin_border_5_1_xml extends ByteArray
   {
      public function habbo_skin_border_5_1_xml()
      {
         super();
      }
   }
}

