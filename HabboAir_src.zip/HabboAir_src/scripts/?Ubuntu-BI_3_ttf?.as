package
{
   import flash.text.Font;
   
   [Embed(source="/_assets/3214_Ubuntu-BI_3_ttf_Ubuntu.ttf",
   fontName="Ubuntu",
   fontFamily="Ubuntu",
   mimeType="application/x-font",
   fontWeight="bold",
   fontStyle="italic",
   unicodeRange="U+0020-007E,U+00A0-017F,U+0192-0192,U+02C6-02C7,U+02C9-02C9,U+02D8-02DD,U+0311-0311,U+0384-0386,U+0388-038A,U+038C-038C,U+038E-0394,U+03A9-03A9,U+03BC-03BC,U+03C0-03C0,U+2013-2015,U+2018-201A,U+201C-201E,U+2020-2022,U+2026-2026,U+2030-2030,U+2039-203A,U+2044-2044,U+2070-2070,U+2074-2079,U+2080-2089,U+20AC-20AC,U+20AE-20AE,U+20B4-20B4,U+20B9-20B9,U+2113-2113,U+2116-2116,U+2122-2122,U+2126-2126,U+212E-212E,U+2153-2159,U+2202-2202,U+2206-2206,U+220F-220F,U+2211-2211,U+2219-221A,U+221E-221E,U+222B-222B,U+2248-2248,U+2260-2260,U+2264-2265,U+25CA-25CA,U+F000-F002",
   advancedAntiAliasing="true",
   embedAsCFF="false"
   )]
   public class §Ubuntu-BI_3_ttf§ extends Font
   {
      public function §Ubuntu-BI_3_ttf§()
      {
         super();
      }
   }
}

