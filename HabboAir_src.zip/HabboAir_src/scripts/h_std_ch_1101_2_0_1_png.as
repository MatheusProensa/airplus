package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/184_h_std_ch_1101_2_0_1_png.png")]
   public class h_std_ch_1101_2_0_1_png extends Bitmap
   {
      public function h_std_ch_1101_2_0_1_png()
      {
         super();
      }
   }
}

