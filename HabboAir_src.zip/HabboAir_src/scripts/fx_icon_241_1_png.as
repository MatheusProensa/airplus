package
{
   import flash.display.Bitmap;
   
   [Embed(source="/_assets/1287_fx_icon_241_1_png.png")]
   public class fx_icon_241_1_png extends Bitmap
   {
      public function fx_icon_241_1_png()
      {
         super();
      }
   }
}

